THERMO CONTROL - proyecto Android para compilar en GitHub Actions

1. Sube TODO el contenido de esta carpeta al nivel raíz de un repositorio GitHub (incluida la carpeta oculta .github).
2. En GitHub abre Actions y ejecuta "Build Thermo Control APK" (o espera a que termine la compilación automática tras subir los archivos).
3. Abre la ejecución completada y descarga el artefacto "thermo-control-debug-apk".
4. Descomprime el artefacto e instala app-debug.apk en tu Android.
5. En la app, abre ⚙ e introduce https://ha.bbouett.win y un token de acceso de larga duración de Home Assistant.

No compartas el token. Se almacena en el almacenamiento local de la aplicación.
Entidades configuradas:
- input_boolean.calefaccion_general
- switch.caldera
- input_boolean.modo_ausente
- climate.dormitorio_cabezal_termostatico_dormitorio
- climate.cabezal_termostatico_bruno

Este es un APK debug generado por GitHub Actions, no una publicación firmada para Play Store.
